<?php

$p = $_POST["p"];
$h = $_POST["h"];
$n = $_POST["n"];

$r = $h * 80;


print('placa;') ;
print($p);
print('número de minutos:');
print($h);
print('nombre cliente:');
print($n);
print('precio total $');
print($r);

?>